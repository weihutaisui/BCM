/*!
* jQuery websocket Library
* version 0.2
* http://www.broadcom.com/
*
* Copyright 2011, Broadcom Corporation
* Dual licensed under the MIT or GPL Version 2 licenses.
* http://jquery.org/license
*
* websocket calls use "id" field to track the caller.
* Server side need to return the id.
* 
* Version history:
* 0.1: 11/1/11. Created. 
*   Requires jQuery 1.6.4.
*
* 0.2: 11/11/11. Added defer to send function.
*   Requires jQuery 1.7
* 
* 0.3: 11/15/11. Added optional onopen, onclose, onerror arguments.
*
* 0.4: 2/8/14. Added keep paramter to send function to keep the dfd around the notify it when msg arrives.
*
* */
(function(a){a.websocket=function(c,f,j,i,h,d){var g=f?new WebSocket(c,f):new WebSocket(c);a(g).bind("message",function(m){if(d){d.call(this,m);return}var l=a.evalJSON(m.originalEvent.data);var k=e.call(this,l);if(k){if(!(k.__keep===null||k.__keep===undefined||k.__keep==false)){k.notify(l)}else{k.resolve(l)}}}).bind("error",function(m){var n=m.originalEvent.data?m.originalEvent.data:m.data;if(n){var l=a.evalJSON(n);var k=e.call(this,l);if(k){k.reject(l)}}else{if(!h){alert(n)}}});if(j){a(g).bind("open",j)}if(i){a(g).bind("close",i)}if(h){a(g).bind("error",h)}function e(l){var m=l.id.toString();var k=a(this).data(m);if(k&&(k.__keep===null||k.__keep===undefined||k.__keep==false)){a(this).removeData(m)}return k}var b=g.send;g.send=function(t,q,r,n,p){if(r===null||r===undefined){r=(10000000*Math.random()).toFixed()}r=r.toString();var l={jsonrpc:"2.0",method:t,params:q,id:r};var o=a.toJSON(l);var k=a.extend(a(this).data(r),a.Deferred());k.__keep=n;a(this).data(r,k);if(p===null||p===undefined){b.call(this,o)}else{p.always(function(){k.notify();b.call(g,o)})}return k};window.onbeforeunload=function(){g.close()};return g}})(jQuery);