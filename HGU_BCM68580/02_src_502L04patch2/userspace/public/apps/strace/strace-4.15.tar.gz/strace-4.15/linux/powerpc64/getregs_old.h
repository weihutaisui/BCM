#include "powerpc/getregs_old.h"
