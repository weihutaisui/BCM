#include "crisv10/set_scno.c"
