static long microblaze_r3;
#define ARCH_PC_PEEK_ADDR PT_PC
