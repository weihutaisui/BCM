#include "powerpc/arch_regs.c"
#undef ARCH_PC_REG
#define ARCH_PC_REG ppc_regs.nip
