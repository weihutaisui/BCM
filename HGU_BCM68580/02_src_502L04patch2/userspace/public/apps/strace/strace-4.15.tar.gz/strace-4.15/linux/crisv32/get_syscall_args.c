#include "crisv10/get_syscall_args.c"
