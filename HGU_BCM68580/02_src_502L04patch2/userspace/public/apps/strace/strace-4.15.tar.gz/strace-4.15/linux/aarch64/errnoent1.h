/* ARM personality */
#include "errnoent.h"
