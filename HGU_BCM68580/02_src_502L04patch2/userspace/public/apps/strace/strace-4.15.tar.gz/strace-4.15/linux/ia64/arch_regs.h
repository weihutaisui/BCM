#include <asm/ptrace_offsets.h>
extern unsigned long *const ia64_frame_ptr;
