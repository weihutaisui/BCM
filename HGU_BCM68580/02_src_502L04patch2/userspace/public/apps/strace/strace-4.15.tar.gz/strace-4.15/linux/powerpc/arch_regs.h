extern struct pt_regs ppc_regs;
