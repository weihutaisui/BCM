static long hppa_r28;
#define ARCH_PC_PEEK_ADDR PT_IAOQ0
