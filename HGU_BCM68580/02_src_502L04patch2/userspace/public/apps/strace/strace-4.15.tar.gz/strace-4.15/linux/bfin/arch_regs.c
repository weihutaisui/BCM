static long bfin_r0;
#define ARCH_PC_PEEK_ADDR PT_PC
