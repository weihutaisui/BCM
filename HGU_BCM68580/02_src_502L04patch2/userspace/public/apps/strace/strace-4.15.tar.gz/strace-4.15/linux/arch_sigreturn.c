#warning sigreturn/rt_sigreturn signal mask decoding is not implemented for this architecture

static void
arch_sigreturn(struct tcb *tcp)
{
}
