XLAT_UOFF(u_tsize),
XLAT_UOFF(u_dsize),
XLAT_UOFF(u_ssize),
XLAT_UOFF(start_code),
/* S390[X] has no start_data */
XLAT_UOFF(start_stack),
XLAT_UOFF(signal),
XLAT_UOFF(u_ar0),
XLAT_UOFF(magic),
XLAT_UOFF(u_comm),
#include "../userent0.h"
