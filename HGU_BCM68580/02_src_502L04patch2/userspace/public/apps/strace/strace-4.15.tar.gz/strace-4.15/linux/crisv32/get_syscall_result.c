#include "crisv10/get_syscall_result.c"
