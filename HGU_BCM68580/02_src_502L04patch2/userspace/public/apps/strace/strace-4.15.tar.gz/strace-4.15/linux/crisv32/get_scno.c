#include "crisv10/get_scno.c"
