#define HAVE_GETREGS_OLD
static int getregs_old(pid_t);
