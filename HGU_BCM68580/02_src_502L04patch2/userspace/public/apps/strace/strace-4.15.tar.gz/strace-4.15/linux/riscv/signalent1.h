/* RISC-V rv32 and rv64 */
#include "../signalent.h"
