static struct user_regs_struct arc_regs;
#define ARCH_REGS_FOR_GETREGSET arc_regs
#define ARCH_PC_REG arc_regs.efa
