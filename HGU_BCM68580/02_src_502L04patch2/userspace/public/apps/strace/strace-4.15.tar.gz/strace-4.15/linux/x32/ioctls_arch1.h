#include "i386/ioctls_arch0.h"
