#include "x86_64/get_scno.c"
