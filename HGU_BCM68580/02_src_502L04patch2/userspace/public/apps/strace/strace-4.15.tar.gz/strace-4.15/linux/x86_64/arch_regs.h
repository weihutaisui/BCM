extern uint32_t *const i386_esp_ptr;
extern uint64_t *const x86_64_rsp_ptr;
