extern long *const m68k_usp_ptr;
