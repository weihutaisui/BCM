static long sh64_r9;
#define ARCH_PC_PEEK_ADDR REG_PC
