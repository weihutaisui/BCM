XLAT_UOFF(u_tsize),
XLAT_UOFF(u_dsize),
XLAT_UOFF(u_ssize),
XLAT_UOFF(signal),
XLAT_UOFF(magic),
XLAT_UOFF(u_comm),
#include "../userent0.h"
