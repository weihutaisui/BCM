#ifdef LINUX_MIPSN64
# include "64/ioctls_inc.h"
#else
# include "32/ioctls_inc.h"
#endif
